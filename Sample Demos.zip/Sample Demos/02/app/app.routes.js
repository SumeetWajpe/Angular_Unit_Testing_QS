"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var view1_component_1 = require("./view/view1.component");
var view2_component_1 = require("./view/view2.component");
var members_component_1 = require("./members/members.component");
var person_component_1 = require("./members/person/person.component");
exports.rootRouterConfig = [
    { path: '', redirectTo: 'view1', pathMatch: 'full' },
    { path: 'view1', component: view1_component_1.View1Component },
    { path: 'view2', component: view2_component_1.View2Component },
    { path: 'members', component: members_component_1.MembersComponent },
    { path: 'person/:id', component: person_component_1.PersonComponent }
];
//# sourceMappingURL=app.routes.js.map