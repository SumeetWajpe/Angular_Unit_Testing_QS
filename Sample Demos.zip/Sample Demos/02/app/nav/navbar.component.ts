import {Component} from '@angular/core';

@Component({
  selector: 'app-navbar',
  moduleId: module.id,
  templateUrl: 'navbar.component.html',
  styleUrls: ['navbar.component.css']
})
export class NavbarComponent {}
