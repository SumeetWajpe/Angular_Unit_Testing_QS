import {Component} from '@angular/core';

@Component({
  selector: 'app-view2',
  template: '<div id="view2">I am view two component</div>'
})
export class View2Component {

}
