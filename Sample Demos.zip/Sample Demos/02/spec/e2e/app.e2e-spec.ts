import { browser, element, by } from 'protractor';

// describe('Given page has a page title and navigation menu', () => {
//   beforeEach( () => {
//     browser.get('');
//   });
//
//   it('Page should have a header title as expected ', function () {
//     expect(element(by.css('h1')).getText()).toEqual('My First Angular 2 App');
//   });
//
//   it('should have <nav>', () => {
//     expect(element(by.css('app-navbar nav')).isPresent()).toEqual(true);
//   });
//
//   it('should have correct nav text for View1', () => {
//     expect(element(by.css('app-navbar nav a:first-child')).getText()).toEqual('View1');
//   });
//
//   it('should have correct nav text for View2', () => {
//     expect(element(by.css('app-navbar nav a:nth-child(2)')).getText()).toEqual('View2');
//   });
//
//   it('should have correct nav text for Search', () => {
//     expect(element(by.css('app-navbar nav a:last-child')).getText()).toEqual('Members');
//   });
//
// });
